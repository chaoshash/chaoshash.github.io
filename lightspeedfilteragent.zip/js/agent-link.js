// Agent-link: localhost WebSocket connection to the native CatchOn
// agent on Windows / macOS. When the agent is reachable, it tells the
// extension which DeviceId and UserId to use, overriding the
// extension's own derivation. This lets a student's URL telemetry
// (from this extension) and DNS / native-app telemetry (from the
// agent) end up keyed on the same identity instead of two separate
// values that report-side joins can't reconcile.
//
// On ChromeOS there is no native agent — the extension is the entire
// data pipeline — so this module is a no-op there. On every other
// platform we attempt a connection on startup; if the agent isn't
// running (dev workstation, agent not yet installed), the connect
// fails quickly and the extension falls back to its existing
// getDeviceSerial / getProfileData behavior.
//
// Wire shape (matches CatchOn-agent-dns-capture-v2/extws):
//   server -> client on connect:
//     { action: "identity", DeviceId, UserId, Username, ReportForwarding }
//       ReportForwarding (bool) advertises that the agent will relay
//       extension reporting payloads to the catcher. Absent/false on
//       old agents -> extension keeps POSTing the catcher directly.
//   client -> server on connect:
//     { action: "hello", version: "<manifest version>" }
//   client -> server periodically:
//     { action: "ping" }
//   server -> client on ping:
//     { action: "pong" }
//   client -> server to forward a report (only when ReportForwarding):
//     { action: "report", id: "<correlation id>", payload: {<catcher payload>} }
//   server -> client ack:
//     { action: "reportAck", id: "<same id>", ok: true }
//       or { action: "reportAck", id, ok: false, error: "..." }
//
//   Report forwarding (the first client->server data path) is double-
//   report-safe: on any forward failure (send error, no ack within
//   REPORT_ACK_TIMEOUT_MS, agent ack ok:false, or connection close) the
//   extension requeues and retries over the WS next cycle — it never
//   falls back to a direct catcher POST while the agent is connected.
//
// Security: the agent only accepts connections whose Origin header is
// `chrome-extension://<our-extension-id>` for the published Chrome
// and Edge IDs. The browser sets this header automatically on
// extension-initiated WebSocket connections, so no client-side work
// is needed beyond connecting to the right URL.

import { logger } from './utils.js';

// Use the explicit IPv4 loopback address. `localhost` would resolve
// to `::1` on dual-stack systems, but the agent only binds to
// 127.0.0.1 — so a localhost connect on those systems would fail
// silently even with the agent running. Hardcoded to match the
// agent's bind on the Go side (extws.DefaultListenAddr).
const AGENT_WS_URL = 'ws://127.0.0.1:6542/websocket';

// Reconnect cadence. Matches LSAlertHelper's pattern (5s). The agent
// has a 30-second hysteresis on its own "extension-connected" gate so
// these reconnect cycles don't flap the agent's DNS upload pause.
const RECONNECT_INTERVAL_MS = 5000;

// Send a ping every PING_INTERVAL_MS so NAT / firewall idle timers
// don't kill the connection. The agent responds with `pong` and the
// connection stays bound to the user session.
const PING_INTERVAL_MS = 30000;

// Module state. Populated when the agent sends an identity message;
// cleared when the WS closes. Access via getAgentIdentity().
let agentIdentity = null;

// Suppression flag for ChromeOS / unsupported platforms. Set once at
// startup; once true, all init work is skipped permanently for this
// service-worker lifetime.
let suppressed = false;

let ws = null;
let reconnectTimer = null;
let pingTimer = null;

// Pending report-forwarding acks, keyed by correlation id.
// value: { resolve, timer } — timer is the ack-timeout handle.
const pendingAcks = new Map();

// Ack timeout. MUST stay strictly greater than the agent's forward
// deadline (extws forwardTimeout, 8s) so that an extension timeout
// reliably implies the catcher did NOT receive the payload — this is
// what makes the requeue-and-retry path (decision #4) double-report
// safe. Also kept well under the MV3 ~30s idle-eviction window so a
// forward resolves within one service-worker lifetime.
const REPORT_ACK_TIMEOUT_MS = 10000;

// shouldRunAgentLink resolves to true on Windows / macOS only. The
// chrome.runtime.getPlatformInfo() API returns os values: 'mac', 'win',
// 'android', 'cros', 'linux', 'openbsd', 'fuchsia'. Only 'mac' and 'win'
// have a CatchOn native agent; 'cros' uses the extension exclusively.
//
// Returns false in any environment where the platform probe doesn't
// resolve cleanly within 1 second — that includes test runners that
// mock `chrome` but don't wire up `getPlatformInfo` callbacks, and
// any future browser engine where the API is missing. We'd rather
// silently no-op than hang the service worker startup waiting for a
// callback that never fires.
function shouldRunAgentLink() {
  return new Promise((resolve) => {
    if (typeof WebSocket === 'undefined') {
      // Test / SSR env without the WebSocket constructor. Cannot
      // connect even if we wanted to.
      resolve(false);
      return;
    }
    // Use `typeof chrome === 'undefined'` rather than `!chrome` —
    // the latter throws ReferenceError in any environment where
    // `chrome` isn't a defined global at all (which is the exact
    // case we're guarding against). `typeof` on an undeclared
    // identifier is the one operation that doesn't throw.
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.getPlatformInfo) {
      resolve(false);
      return;
    }
    let resolved = false;
    let failSafeTimer = null;
    const finish = (result) => {
      if (resolved) return;
      resolved = true;
      if (failSafeTimer) {
        // Clear the timer so it doesn't keep the MV3 service worker
        // alive (or hold up Node test processes) after the platform
        // probe has returned.
        clearTimeout(failSafeTimer);
        failSafeTimer = null;
      }
      resolve(result);
    };
    // Fail-safe timeout: if the chrome stub doesn't invoke our
    // callback (sinon-chrome behavior under tests), we give up after
    // 1s and stay disabled.
    failSafeTimer = setTimeout(() => finish(false), 1000);
    try {
      chrome.runtime.getPlatformInfo((info) => {
        const os = info && info.os;
        finish(os === 'mac' || os === 'win');
      });
    } catch (e) {
      finish(false);
    }
  });
}

function clearTimers() {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
  if (pingTimer) {
    clearInterval(pingTimer);
    pingTimer = null;
  }
}

function scheduleReconnect() {
  clearTimers();
  if (suppressed) return;
  reconnectTimer = setTimeout(connect, RECONNECT_INTERVAL_MS);
}

function onOpen() {
  logger.info('[agent-link] connected to native agent');
  // Send a hello so the agent logs which extension version is on the
  // line (helps ops triage version-mismatch problems).
  try {
    const manifest = chrome.runtime.getManifest();
    ws.send(JSON.stringify({ action: 'hello', version: manifest.version }));
  } catch (e) {
    logger.info('[agent-link] hello send failed', e);
  }

  // Start pinging.
  if (pingTimer) clearInterval(pingTimer);
  pingTimer = setInterval(() => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      try {
        ws.send(JSON.stringify({ action: 'ping' }));
      } catch (e) {
        logger.info('[agent-link] ping send failed', e);
      }
    }
  }, PING_INTERVAL_MS);
}

function onMessage(event) {
  let msg;
  try {
    msg = JSON.parse(event.data);
  } catch (e) {
    logger.info('[agent-link] bad json from agent', e);
    return;
  }
  switch (msg.action) {
    case 'identity':
      // Adopt the agent's identity values. Empty string fields mean
      // "the agent doesn't know yet" — keep any prior agentIdentity
      // populated rather than blanking it out, since we'd rather use
      // a slightly-stale identity than zero out and fall back.
      agentIdentity = {
        deviceId: msg.DeviceId || (agentIdentity && agentIdentity.deviceId) || null,
        userId: msg.UserId || (agentIdentity && agentIdentity.userId) || null,
        username: msg.Username || (agentIdentity && agentIdentity.username) || null,
        reportForwarding: msg.ReportForwarding === true,
      };
      logger.info('[agent-link] identity from agent ->', agentIdentity);
      break;
    case 'pong':
      // Heartbeat ack. Nothing to do.
      break;
    case 'reportAck': {
      const pending = pendingAcks.get(msg.id);
      if (!pending) {
        logger.info('[agent-link] reportAck for unknown id ->', msg.id);
        break;
      }
      clearTimeout(pending.timer);
      pendingAcks.delete(msg.id);
      // Always resolve (never reject) with a uniform { ok, error } shape.
      pending.resolve({
        ok: msg.ok === true,
        error: msg.ok === true ? undefined : (msg.error || 'agent reported failure'),
      });
      break;
    }
    default:
      logger.info('[agent-link] unknown action from agent ->', msg.action);
  }
}

function onClose() {
  logger.info('[agent-link] disconnected from native agent');
  // Clear the cached identity so getAgentIdentity() returns null and
  // callers fall back to the extension's own derivation. This is the
  // documented contract — we don't want to keep using a stale agent
  // identity after we've lost contact, since the user could have
  // switched accounts on the device.
  agentIdentity = null;
  // Fail any in-flight report forwards so callers unblock and requeue.
  pendingAcks.forEach((pending) => {
    clearTimeout(pending.timer);
    pending.resolve({ ok: false, error: 'agent connection closed before ack' });
  });
  pendingAcks.clear();
  ws = null;
  clearTimers();
  scheduleReconnect();
}

function onError(err) {
  // 'error' fires before 'close' on connection failures. Don't log at
  // a noisy level — on machines where the agent isn't installed,
  // every reconnect attempt would produce an error. Trace-level only.
  logger.info('[agent-link] connection error', err && err.message);
}

function connect() {
  if (suppressed) return;
  // Defensive: if WebSocket has gone undefined since init() resolved
  // (teardown in unit tests, or a future runtime that strips the
  // constructor), just stop. Without this guard, a reconnect timer
  // that fires after the test process has cleared globalThis.WebSocket
  // throws ReferenceError and crashes mocha's exit path.
  if (typeof WebSocket === 'undefined') return;
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    return;
  }
  try {
    ws = new WebSocket(AGENT_WS_URL);
  } catch (e) {
    logger.info('[agent-link] failed to construct WebSocket', e);
    scheduleReconnect();
    return;
  }
  ws.onopen = onOpen;
  ws.onmessage = onMessage;
  ws.onclose = onClose;
  ws.onerror = onError;
}

// init kicks off the WS connection if and only if the host is Win/Mac.
// Safe to call multiple times — re-entry is a no-op once connected.
async function init() {
  if (!await shouldRunAgentLink()) {
    suppressed = true;
    logger.info('[agent-link] platform does not run a native agent; skipping');
    return;
  }
  connect();
}

// getAgentIdentity returns the agent-supplied identity if the agent is
// currently connected and has sent its identity message, or null
// otherwise. Returns { deviceId, userId, username } when populated.
//
// Callers in background.js should prefer this over getDeviceSerial /
// getProfileData when it returns non-null, and fall back to the
// extension's own values otherwise. See getDeviceSerialOverride and
// getUserIdOverride below for the canonical wrappers.
function getAgentIdentity() {
  return agentIdentity;
}

// getDeviceSerialOverride returns the agent-supplied DeviceId if
// available, or null otherwise. The caller uses null as the signal to
// fall back to the extension's getDeviceSerial().
function getDeviceSerialOverride() {
  return agentIdentity && agentIdentity.deviceId ? agentIdentity.deviceId : null;
}

// getUserIdOverride returns the agent-supplied UserId if available, or
// null otherwise.
//
// IMPORTANT semantics: the agent's UserId is md5(lowercase trimmed OS
// username). The extension's default userData.hash is md5(lowercase
// trimmed email of the signed-in chrome account). These are NOT
// numerically equal for the same student — `tyler.morrison` (OS) vs
// `tmorrison@rwisd.org` (email) hash to different values.
//
// When the agent is connected, both pipelines (extension URLs and
// agent DNS / native-app screentime) end up using the agent's value,
// so they correlate correctly. Pre-existing extension URL data
// keyed on email-hash will look like a different student in the
// catcher's storage layer until that data ages out — which is
// acceptable because adoption of the agent on a device is a
// deliberate transition, not a silent migration.
function getUserIdOverride() {
  return agentIdentity && agentIdentity.userId ? agentIdentity.userId : null;
}

// isAgentConnected returns true if the WS is open and the agent has
// pushed its identity at least once. Useful for dashboards / popup UI
// indicators.
function isAgentConnected() {
  return ws !== null && ws.readyState === WebSocket.OPEN && agentIdentity !== null;
}

// sendReportViaAgent forwards a complete catcher payload to the agent
// over the WS and resolves once the agent acks (or the ack times out /
// the connection drops). Resolves { ok: true } on success or
// { ok: false, error } on any failure — it never rejects, so the
// caller in background.js can branch on `ok` and requeue per decision #4.
function sendReportViaAgent(id, payload) {
  return new Promise((resolve) => {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      resolve({ ok: false, error: 'agent not connected' });
      return;
    }
    if (pendingAcks.has(id)) {
      resolve({ ok: false, error: 'duplicate correlation id' });
      return;
    }
    const timer = setTimeout(() => {
      pendingAcks.delete(id);
      resolve({ ok: false, error: 'report forwarding timed out waiting for server ack' });
    }, REPORT_ACK_TIMEOUT_MS);
    pendingAcks.set(id, { resolve, timer });
    try {
      ws.send(JSON.stringify({ action: 'report', id, payload }));
    } catch (e) {
      clearTimeout(timer);
      pendingAcks.delete(id);
      resolve({ ok: false, error: `report send failed: ${e && e.message}` });
    }
  });
}

// getReportForwardingCapability reports whether the connected agent has
// advertised report-forwarding support (decision #5). False when not
// connected, when the agent is an old build that omits the flag, or
// when the agent has no report sink wired.
function getReportForwardingCapability() {
  return !!(agentIdentity && agentIdentity.reportForwarding);
}

export {
  init,
  getAgentIdentity,
  getDeviceSerialOverride,
  getUserIdOverride,
  isAgentConnected,
  sendReportViaAgent,
  getReportForwardingCapability,
};
