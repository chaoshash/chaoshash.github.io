// filter-link: query the Lightspeed Filter Agent (ChromeMobileFilter)
// for URL block status, so CatchOn can suppress reporting on URLs
// that the filter would have blocked anyway.
//
// The Filter Agent exposes a `scoreUrl` external message action (see
// ChromeMobileFilter/dev/src/helper.js — case 'scoreUrl'). It replies
// with { blocked: true|false }, doing its own internal lookup +
// short poll if the host's category isn't yet cached. The Filter
// Agent's manifest externally_connectable list includes this
// extension's published Chrome and Edge IDs, so production installs
// of both extensions can talk to each other directly.
//
// The Filter Agent isn't always installed — on dev workstations or
// districts that don't deploy it, sendMessage fails with
// chrome.runtime.lastError set to "Could not establish connection".
// That is the documented signal for "filter not present"; we treat
// any non-`blocked:true` response (including connection failures,
// timeouts, and malformed replies) as "not blocked" so the extension
// reports the activity as it would have before this module existed.
//
// Results are cached in-memory with a short TTL. Without the cache,
// every tab activation + URL update would re-issue a scoreUrl on the
// same URL, multiplying messaging volume while the user clicks
// around. The TTL is short enough that filter policy edits propagate
// quickly without operators having to restart the browser.

import { logger } from './utils.js';

// Production Filter Agent extension ID. Matches the hardcoded target
// in LsFilterHelperAgent/dev/src/remote_chrome.js — the filter is
// single-tenant per browser install, so there is no separate
// dev/staging extension ID to handle.
const FILTER_EXTENSION_ID = 'ehnniokiiebpinnfegpkdlcamgdcaaje';

// scoreUrl response timeout. The filter's own poll budget is 2s (20
// attempts x 100ms in helper.js); add headroom for message-channel
// overhead so we don't time out a lookup the filter is about to
// answer.
const QUERY_TIMEOUT_MS = 3000;

// Cache TTL. Five minutes balances freshness against lookup volume —
// short enough that a policy edit shows up on the next activity-send
// cycle for most users, long enough that repeated navigations to the
// same URL don't requery.
const CACHE_TTL_MS = 5 * 60 * 1000;

// blockedCache stores per-URL { blocked: boolean, expiry: number }.
const blockedCache = new Map();

function cacheGet(url) {
  const entry = blockedCache.get(url);
  if (!entry) return undefined;
  if (Date.now() > entry.expiry) {
    blockedCache.delete(url);
    return undefined;
  }
  return entry.blocked;
}

function cacheSet(url, blocked) {
  blockedCache.set(url, { blocked, expiry: Date.now() + CACHE_TTL_MS });
}

// isUrlBlocked asks the Filter Agent whether `url` would be blocked
// under the active filter policy. Resolves to true only when the
// Filter Agent is installed AND it reports the URL as blocked. Any
// other outcome resolves to false so the caller's default behavior
// (report the activity) is preserved.
async function isUrlBlocked(url) {
  if (!url) return false;
  // Guard against test environments / future browser engines where
  // chrome.runtime.sendMessage isn't present. Without this guard the
  // call below throws synchronously and the promise chain that
  // dispatched this check would surface an uncaught rejection.
  if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
    return false;
  }
  const cached = cacheGet(url);
  if (cached !== undefined) return cached;

  return new Promise((resolve) => {
    let settled = false;
    const settle = (blocked) => {
      if (settled) return;
      settled = true;
      cacheSet(url, blocked);
      resolve(blocked);
    };

    const timeoutId = setTimeout(() => {
      // The filter agent should always reply within its own 2s poll
      // budget; a true timeout here means the message channel itself
      // is wedged. Log at info level so we can spot it in ops without
      // pager noise.
      logger.info('[filter-link] scoreUrl timeout ->', url);
      settle(false);
    }, QUERY_TIMEOUT_MS);

    try {
      chrome.runtime.sendMessage(
        FILTER_EXTENSION_ID,
        { action: 'scoreUrl', url },
        (response) => {
          clearTimeout(timeoutId);
          if (chrome.runtime.lastError) {
            // Most common cause: Filter Agent not installed. Reading
            // lastError clears Chrome's "unchecked" warning. Don't log
            // at higher than info — every browser without the Filter
            // Agent would otherwise produce noise on every URL.
            settle(false);
            return;
          }
          settle(Boolean(response && response.blocked === true));
        },
      );
    } catch (e) {
      clearTimeout(timeoutId);
      logger.info('[filter-link] sendMessage threw ->', e && e.message);
      settle(false);
    }
  });
}

// __resetForTests clears the in-memory cache. Exposed for unit tests
// so each case starts from a clean state; not part of the public API.
function __resetForTests() {
  blockedCache.clear();
}

export {
  isUrlBlocked,
  FILTER_EXTENSION_ID,
  CACHE_TTL_MS,
  QUERY_TIMEOUT_MS,
  __resetForTests,
};
