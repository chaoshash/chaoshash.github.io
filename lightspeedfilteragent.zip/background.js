import {
  getProfileData, getDeviceSerial, getHostname, getDeviceType, getPlatform,
  getCPU, getStorage, getMemory, getOS, getOSVersion,
} from './js/identity.js';
import {
  logger, getDefaultConfig, getManagedValue, getManifest, CriticalError, wait, getRandomInt,
} from './js/utils.js';
import { getConfig, checkKey, sendData } from './js/api.js';
import speedTest from './js/speed_test.js';
import * as agentLink from './js/agent-link.js';
import { isUrlBlocked } from './js/filter-link.js';

// Kick off the localhost WebSocket connection to the native CatchOn
// agent on Win/Mac. No-op on ChromeOS. When the agent is reachable,
// the extension adopts its DeviceId/UserId so URL telemetry rows
// correlate with DNS / native-app rows on (DeviceId, UserId).
//
// Skipped under NODE_ENV=test (matching the runMainUntilSuccess gate
// at the bottom of this file). Without this gate, importing
// background.js from a unit test schedules a stray reconnect timer
// and keeps the test process alive past mocha's normal exit. The
// production extension service worker has no `process` global so
// the typeof check resolves to "production path".
if (typeof process === 'undefined' || typeof process.env === 'undefined' || process.env.NODE_ENV !== 'test') {
  agentLink.init();
}

// resolveDeviceId returns the agent's DeviceId if the native agent is
// connected, otherwise the extension's own getDeviceSerial result.
// Centralized here so every payload-build callsite gets the same
// override behavior; a future change to the override semantics only
// has to touch this function.
async function resolveDeviceId() {
  const fromAgent = agentLink.getDeviceSerialOverride();
  if (fromAgent) return fromAgent;
  return getDeviceSerial();
}

// resolveUserId returns the agent's UserId if available, otherwise
// the extension's md5(email) hash. See agent-link.js for the
// semantic-mismatch note: agent UserId = md5(OS username), extension
// UserId = md5(email). When the agent is connected, both pipelines
// converge on the agent's value so reports correlate correctly.
//
// Callers that have already fetched profile data (sendActivity needs
// userData for PII fields) can pass the precomputed hash to avoid a
// duplicate chrome.identity.getProfileUserInfo call. Passing it also
// keeps the identifier source consistent within a single payload
// build — no risk of the email-hash changing between two
// getProfileData() calls a few microseconds apart.
async function resolveUserId(fallbackHash) {
  const fromAgent = agentLink.getUserIdOverride();
  if (fromAgent) return fromAgent;
  if (fallbackHash) return fallbackHash;
  const userData = await getProfileData();
  return userData.hash;
}

// resolveUserData returns the signed-in browser profile (email, hash,
// username, domain) used to populate PII fields — and, when the native
// agent is NOT supplying an identity, the UserId hash.
//
// When there is no signed-in browser user, getProfileData rejects with a
// CriticalError. That is only fatal when the extension has no other
// source of identity. When the native CatchOn agent is connected and has
// handed us a UserId (agentLink.getUserIdOverride()), the agent is doing
// the user identification, so a missing browser profile is expected and
// non-fatal: we return null and let resolveUserId / getPIIData fall back
// to the agent's values, so reporting keeps flowing even on a device with
// no signed-in browser account. Without an agent UserId we rethrow,
// preserving the existing "no signed-in profile" gate exactly.
async function resolveUserData() {
  try {
    return await getProfileData();
  } catch (e) {
    if (e instanceof CriticalError && agentLink.getUserIdOverride()) {
      logger.info('[resolveUserData] no signed-in browser user; using native agent identity');
      return null;
    }
    throw e;
  }
}

// global variables
let activities = {};
let config = {};
// no status set initially, so that it sets the correct logo
let enabled = null;
let currentIP = null;
let currentLatitude;
let currentLongitude;
const OFFSCREEN_DOCUMENT_PATH = '/location.html';
// A global promise to avoid concurrency issues
let creating;
let locating;
// Track last online status
let currentConnectionStatus = navigator.onLine;
let lastOfflineDetails = {};

// Alarms
const min1 = 60000;
const min5 = 300000;
const min10 = 600000;
const min15 = 900000;
let sendActivityInt = min15;
let agentStatusInt = min10;
let speedLocationInt = min5;
let lastActivityInt = min15;
let speedTestInProgress = false;
let lastSend;
let userIdle = false;
let keepAliveInterval;
let lastFocusWindowId = null;
let lastRealFocusWindowId = null;
let lastTick = Date.now();
const HEARTBEAT = 20000; // 20 seconds
const HEARTBEAT_THRESHOLD_MULTIPLIER = 2; // 2 times the heartbeat interval

function getLocalStorage(name) {
  return new Promise((resolve) => {
    chrome.storage.local.get([name], (data) => {
      if (chrome.runtime.lastError) {
        logger.info('[getLocalStorage] error:', chrome.runtime.lastError.message);
        resolve(undefined);
        return;
      }
      if (data) {
        logger.info('[getLocalStorage] -> ', data[name]);
        resolve(data[name]);
      }
    });
  });
}

async function setLastSend(name) {
  lastSend[name] = Date.now();
  await chrome.storage.local.set({ lastSend });
}

function timeToRun(last, int) {
  const now = Date.now();
  return (now - last) > int;
}

async function hasDocument() {
  // Check all windows controlled by the service worker to see if one
  // of them is the offscreen document with the given path
  const matchedClients = await clients.matchAll();

  return matchedClients.some(
    (c) => c.url === chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH),
  );
}

async function setupOffscreenDocument(path) {
  // if we do not have a document, we are already setup and can skip
  if (!(await hasDocument())) {
    // create offscreen document
    if (creating) {
      await creating;
    } else {
      creating = chrome.offscreen.createDocument({
        url: path,
        reasons: [
          chrome.offscreen.Reason.GEOLOCATION
          || chrome.offscreen.Reason.DOM_SCRAPING,
        ],
        justification: 'Get geolocation for Digital Equity',
      });

      await creating;
      creating = null;
    }
  }
}

async function closeOffscreenDocument() {
  if (!(await hasDocument())) {
    return;
  }
  await chrome.offscreen.closeDocument();
}

async function getGeolocation() {
  await setupOffscreenDocument(OFFSCREEN_DOCUMENT_PATH);

  const geolocation = await chrome.runtime.sendMessage({
    type: 'get-geolocation',
    target: 'offscreen',
  });

  await closeOffscreenDocument();
  if (geolocation.error) {
    throw new Error(geolocation.error.message);
  }
  return geolocation;
}

const platform = getPlatform();

logger.info(`Got platform: ${platform}`);

const isCollectionEnabled = () => config.active;

const enableExtension = () => {
  if (enabled === true || process?.env?.NODE_ENV === 'test') {
    // already enabled, nothing to do here
    return;
  }
  enabled = true;
  chrome.action.setIcon({
    path: {
      16: 'images/digital-insight(16x16).png',
      32: 'images/digital-insight(32x32).png',
      48: 'images/digital-insight(48x48).png',
      128: 'images/digital-insight(128x128).png',
    },
  });
  chrome.action.setPopup({
    popup: 'popup.html',
  });
};

const disableExtension = () => {
  if (enabled === false) {
    // already disabled, nothing to do here
    return;
  }
  enabled = false;
  chrome.action.setIcon({
    path: {
      16: 'images/digital-insight(16x16)-disabled.png',
      32: 'images/digital-insight(32x32)-disabled.png',
      48: 'images/digital-insight(48x48)-disabled.png',
      128: 'images/digital-insight(128x128)-disabled.png',
    },
  });
  chrome.action.setPopup({
    popup: 'popup-disabled.html',
  });
};

const checkCollectionStatus = () => {
  if (!isCollectionEnabled()) {
    // do not send activity if collection is disabled
    // mark the extension as disabled
    disableExtension();
    return;
  }
  enableExtension();
};

const setCount = (activity) => {
  const maxDuration = sendActivityInt;
  // Filter out any invalid intervals where End <= Start
  const validIntervals = activity.Intervals.filter((interval) => {
    if (!interval.End || !interval.Start || interval.End <= interval.Start) {
      logger.info('Filtering out invalid interval:', interval);
      return false;
    }
    return true;
  }).reduce((acc, interval) => {
    // Use inclusive [Start, End] convention consistent with the rest of the module
    const duration = interval.End - interval.Start + 1;
    if (duration > maxDuration) {
      logger.info('Splitting oversized interval:', interval);
      let start = interval.Start;
      while (start <= interval.End) {
        const end = Math.min(start + maxDuration - 1, interval.End);
        acc.push({ Start: start, End: end });
        start = end + 1;
      }
    } else {
      acc.push(interval);
    }
    return acc;
  }, []);

  return {
    ...activity,
    Intervals: validIntervals,
    Count: validIntervals.length,
  };
};

const getActivities = () => activities;
const clearActivities = () => {
  activities = {};
};

const getActiveActivityKey = () => Object.keys(activities).find(
  (url) => activities[url].Intervals.find((interval) => !interval.End),
);

const checkActivityValues = (activityValues) => {
  if (!activityValues || activityValues.length === 0) {
    throw new Error('No activities to send');
  }
};

const getActivityToSend = () => {
  const activeActivityKey = getActiveActivityKey();
  let activeActivity;
  logger.info('Active activity', activeActivityKey);
  if (activeActivityKey) {
    activeActivity = activities[activeActivityKey];

    setActivityScreenTimeEnd();
  }
  const discardTimestamp = Date.now() - (config.maxAge * 60 * 1000);
  const allActivities = Object.values(activities)
    .filter(({ Timestamp }) => Timestamp > discardTimestamp);
  const chunkSize = config.payloadActivityMaxCount || 500;
  // take the first X values, to reduce the payload size
  const activityValues = allActivities.slice(0, chunkSize).map(setCount);
  checkActivityValues(activityValues);
  // cleanup the object, so that everything collected while the request in progress is recorded
  clearActivities();
  if (activeActivity && !userIdle) {
    // set the one that was already in progress (only if user is still active)
    const Start = Date.now();
    const h = (new Date(Start)).getHours();
    const { Url } = activeActivity;
    const activeKey = `${h}-${Url}`;
    activities[activeKey] = {
      Intervals: [],
      Timestamp: Start,
      Url,
    };

    setIntervalStart(activeKey, Start, Url);
  }
  logger.info(`Sending ${activityValues.length} out of ${allActivities.length}`);
  return { activityValues, allActivities };
};

const getPIIData = (userData, hostname) => {
  if (!config.collectPII) return undefined;
  // When no browser user is signed in, the native agent is supplying
  // identity (see resolveUserData). Fall back to the agent's Username —
  // the only PII field it provides over the link — and omit Email/Domain,
  // which are unknown without a browser profile. JSON.stringify drops the
  // undefined keys, so the row carries only what we actually know.
  if (!userData) {
    const agentId = agentLink.getAgentIdentity();
    return {
      Username: agentId && agentId.username ? agentId.username : undefined,
      Hostname: hostname,
    };
  }
  return {
    Email: userData.email,
    Username: userData.username,
    Domain: userData.domain,
    Hostname: hostname,
  };
};

const getRemainingActivities = (allActivities) => {
  const chunkSize = config.payloadActivityMaxCount || 500;
  // clear/reduce activity
  const restActivities = allActivities.slice(chunkSize);
  // recreate the object by url
  return restActivities.reduce((mapping, item) => {

    mapping[item.Url] = item;
    return mapping;
  }, {});
};

const addInProgressActivities = (remainingActivities) => {
  // add all that have been tracked while the request was in progress
  Object.keys(activities).forEach((url) => {
    if (!remainingActivities[url]) {

      remainingActivities[url] = activities[url];
    }
  });
};

const saveActivitiesInStorage = () => new Promise((resolve) => {
  chrome.storage.local.set({ activities: JSON.stringify(activities) }, resolve);
});

const readActivitiesFromStorage = () => new Promise((resolve) => {
  chrome.storage.local.get(['activities'], (result) => resolve(JSON.parse(result.activities || '{}')));
});

const recreateActivitiesAfterSend = (allActivities) => {
  const remainingActivities = getRemainingActivities(allActivities);
  addInProgressActivities(remainingActivities);
  // update the object
  activities = remainingActivities;
  saveActivitiesInStorage();
};

// Re-inserts unsent activities back into the in-memory activities object after a
// failed send. Unlike the previous clone-based restore, the activities passed here
// already have their intervals closed (End is set) by getActivityToSend(), so they
// will not continue to grow across subsequent retry cycles. Any new intervals
// collected during the in-flight request are preserved (merge, not overwrite).
const mergeActivitiesBack = (activitiesToRestore) => {
  activitiesToRestore.forEach((activity) => {
    const { Url, Timestamp } = activity;
    (activity.Intervals || []).forEach((interval) => {
      // Reconstruct the {hour}-{url} key used by the activities object
      const h = (new Date(interval.Start)).getHours();
      const key = `${h}-${Url}`;
      if (!activities[key]) {
        activities[key] = { Intervals: [], Timestamp, Url };
      }
      // Avoid duplicating intervals that may already exist (e.g. from the
      // active page interval re-created by getActivityToSend after clearing)
      const isDuplicate = activities[key].Intervals.some(
        (existing) => existing.Start === interval.Start && existing.End === interval.End,
      );
      if (!isDuplicate) {
        activities[key].Intervals.push(interval);
      }
      if (Timestamp > activities[key].Timestamp) {
        activities[key].Timestamp = Timestamp;
      }
    });
  });
};

const sendActivity = async () => {
  checkCollectionStatus();
  const { activityValues, allActivities } = getActivityToSend();
  // build data
  // retrieve data identifiers — when the native CatchOn agent is
  // connected on localhost, resolveDeviceId / resolveUserId return
  // the agent's values so this row correlates with the agent's DNS
  // and native-app screentime rows. Falls back to the extension's
  // own derivation otherwise (ChromeOS, agent not installed).
  //
  // userData may be null when there is no signed-in browser user: in
  // that case the agent is doing the identification, so we keep sending
  // and use the agent's UserId/DeviceId/Username. resolveUserData
  // rethrows only when there is no browser user AND no agent identity.
  const userData = await resolveUserData();
  const machineId = await resolveDeviceId();
  // Pass userData.hash as the fallback so we don't make a second
  // chrome.identity.getProfileUserInfo call when the agent isn't
  // connected — see resolveUserId comments. Null when no browser user
  // is signed in (resolveUserId then returns the agent's UserId).
  const userId = await resolveUserId(userData && userData.hash);
  const hostname = await getHostname();
  const deviceType = await getDeviceType();
  const key = await getManagedValue('EntitlementKey');
  const deviceOSVersion = await getOSVersion();

  const manifest = getManifest();

  const sentAt = Date.now();
  const body = {
    Version: manifest.version,
    DeviceId: machineId,
    DeviceOSVersion: deviceOSVersion,
    UserId: userId,
    ...getPIIData(userData, hostname),
    EntitlementKey: key,
    Platform: platform === 'chrome' ? 'catchon-extension' : platform,
    DeviceType: deviceType,
    ActivityList: activityValues.map((activity) => ({
      ...activity,
      Timestamp: Math.min(activity.Timestamp, sentAt - 1),
    })),
    SentAt: sentAt,
  };
  // send it
  try {
    let res = null;
    const agentConnected = agentLink.isAgentConnected();
    const agentCanForward = agentLink.getReportForwardingCapability();
    if (agentConnected && agentCanForward) {
      // Route through the native agent, which relays this payload verbatim
      // to the catcher. On ANY failure we do NOT fall back to a direct POST
      // while the agent is connected — we throw so the catch block requeues
      // and we retry over the WS next cycle (decision #4). This guarantees
      // zero double-report: the agent's forward deadline (8s) is strictly
      // under our ack timeout (10s), so a timeout here means the catcher did
      // not receive the payload.
      const correlationId = `activity-${sentAt}-${getRandomInt(0, 999999)}`;
      logger.info('[sendActivity] forwarding via agent, id:', correlationId);
      const ack = await agentLink.sendReportViaAgent(correlationId, body);
      if (!ack.ok) {
        throw new Error(`agent report forwarding failed: ${ack.error || 'unknown'}`);
      }
      // currentIP is left untouched on this path: the agent does not relay
      // the catcher's request-source header. currentIP only feeds DE gating
      // downstream; leaving it unchanged is correct (do NOT stub it).
    } else {
      // Direct POST (ChromeOS, agent absent, or agent lacks capability).
      res = await sendData({
        url: config.endpointURL,
        body,
      });
    }
    if (res) {
      currentIP = res.headers.get('request-source');
    }
    recreateActivitiesAfterSend(allActivities);
  } catch (e) {
    // On any failure (5xx, 404, network error, etc.), put unsent activities back.
    // allActivities has intervals already closed by getActivityToSend(), so they
    // won't grow on subsequent retries. This also prevents silent data loss for
    // network errors that the previous clone-based approach did not handle.
    mergeActivitiesBack(allActivities);
    saveActivitiesInStorage();
    throw e;
  }
};

const trySendActivity = async () => {
  if (!lastSend.lastSendActivity || timeToRun(lastSend.lastSendActivity, sendActivityInt)) {
    logger.info('[trySendActivity]');
    await setLastSend('lastSendActivity');
    try {
      await sendActivity();
    } catch (e) {
      logger.info(`Error sending activity: ${e.message}`);
      if (e instanceof CriticalError) {
        throw e;
      }
    }
  }
};

const updateSendInterval = () => {
  sendActivityInt = config.sendInterval * min1;
  logger.info('[updateSendInterval] send activity interval ->', sendActivityInt / 60000, 'min');
};

const setIntervalForSpeedAndLocation = () => {
  speedLocationInt = (config.sendInterval + 1) * min1;
  logger.info('[setIntervalForSpeedAndLocation] speedtest interval ->', speedLocationInt / 60000, 'min');
};

const updateLastActivityInterval = () => {
  lastActivityInt = (config.inactiveTimeout / 60) * min1;
  logger.info('[updateLastActivityInterval] idle timeout ->', lastActivityInt / 60000, 'min');
};

const updateCheckAgentStatus = () => {
  agentStatusInt = (config.checkinInterval / 60) * min1;
  logger.info('[updateCheckAgentStatus] agent check status interval ->', agentStatusInt / 60000, 'min');
};

const checkAgentStatus = async () => {
  if (!lastSend.lastAgentStatus || timeToRun(lastSend.lastAgentStatus, agentStatusInt)) {
    logger.info('[checkAgentStatus] start');
    try {
      const newConfig = await getConfig(config);
      await setLastSend('lastAgentStatus');
      Object.assign(config, newConfig);
      logger.info('[checkAgentStatus] -> ', config);
      await chrome.storage.local.set({ config });
      updateSendInterval();
      updateLastActivityInterval();
      // check for Speed and Location every x minutes
      setIntervalForSpeedAndLocation();
      checkCollectionStatus();
    } finally {
      updateCheckAgentStatus();
      logger.info('[checkAgentStatus] done');
    }
  }
};

const setIntervalStartInMemory = (key, Start, url) => {
  if (!activities[key]) {
    activities[key] = {
      Intervals: [],
      Timestamp: Start,
      Url: url,
    };
  }
  const openInterval = activities[key].Intervals.find(({ End }) => !End);
  if (!openInterval) {
    logger.info('Start tracking activity for', key, { Start });
    activities[key].Intervals.push({
      Start,
    });
  }
};

const setIntervalEndInMemory = (key, end = Date.now()) => {
  if (!activities[key] || !activities[key].Intervals) {
    logger.info('No activity found for key:', key);
    return false;
  }
  let changed = false;
  activities[key].Intervals.forEach((interval) => {
    if (!interval.End) {
      const validEnd = Math.max(end, interval.Start);

      interval.End = validEnd;
      activities[key].Timestamp = validEnd;
      changed = true;
      logger.info('End tracking activity for', key, interval);
    }
  });
  return changed;
};

const setIntervalStart = (key, Start, url) => {
  setIntervalStartInMemory(key, Start, url);
  saveActivitiesInStorage();
};

// dropBlockedActivity removes any activities-map entries whose Url
// matches the blocked URL. We can't rely on the original `${h}-${url}`
// key alone because the filter check is async — by the time it
// resolves, the user could have rolled past the hour boundary and a
// bridging interval (setActivityScreenTimeEnd) could have created a
// second key for the same URL. Sweeping by Url catches both.
const dropBlockedActivity = (url) => {
  let removed = false;
  Object.keys(activities).forEach((key) => {
    if (activities[key] && activities[key].Url === url) {
      delete activities[key];
      removed = true;
    }
  });
  if (removed) {
    saveActivitiesInStorage();
  }
  return removed;
};

const setActivityForTab = (tab, start) => {
  const { url } = tab;
  if (!url) {
    // wait for url to be set (new tab)
    return;
  }
  const h = (new Date(start)).getHours();
  const key = `${h}-${url}`;
  setIntervalStart(key, start, url);

  // Ask the Filter Agent whether this URL would be blocked by the
  // active filter policy. We start tracking first and retroactively
  // drop the entry if blocked — the filter's lookup can take up to
  // ~2s, and starting/then-dropping avoids losing screen time on
  // URLs that turn out not to be blocked. On installs without the
  // Filter Agent, isUrlBlocked resolves to false and this is a
  // no-op. See src/js/filter-link.js.
  isUrlBlocked(url)
    .then((blocked) => {
      if (blocked) {
        logger.info('[setActivityForTab] filter blocked URL, suppressing activity ->', url);
        dropBlockedActivity(url);
      }
    })
    .catch((e) => {
      logger.info('[setActivityForTab] filter check failed ->', e && e.message);
    });
};

// workaround for issue https://bugs.chromium.org/p/chromium/issues/detail?id=1213925
const ChromeWrapper = {
  chromeTabsQuery(params, callback) {
    chrome.tabs.query(params, (tabs) => {
      if (chrome.runtime.lastError) {
        setTimeout(() => {
          ChromeWrapper.chromeTabsQuery(params, callback);
        }, 50);
      } else {
        callback(tabs);
      }
    });
  },
};

const getActiveTabs = (id) => new Promise((resolve) => {
  // chrome.tabs.query({ active: true, windowId: id }, resolve);
  ChromeWrapper.chromeTabsQuery({ active: true, windowId: id }, resolve);
});

const setActivityScreenTimeStart = async (
  id = chrome.windows.WINDOW_ID_NONE,
  Start = Date.now(),
) => {
  if (!isCollectionEnabled()) {
    // do not collect activity if collection is disabled
    return;
  }
  if (userIdle) {
    // do not open new intervals while user is idle
    return;
  }
  const tabs = await getActiveTabs(id);
  if (tabs.length !== 1) {
    // No active tab (window may have been closed) or multiple tabs active
    // (multiple windows, none focused via WINDOW_ID_NONE)
    return;
  }
  const [tab] = tabs;
  setActivityForTab(tab, Start);
};

const getStartOfTheHour = (timestamp = Date.now()) => {
  const date = new Date(timestamp);
  const milis = date.getMilliseconds();
  const sec = date.getSeconds();
  const min = date.getMinutes();
  return timestamp - min * 60 * 1000 - sec * 1000 - milis;
};

const setIntervalEnd = (key, end = Date.now()) => {
  if (setIntervalEndInMemory(key, end)) {
    saveActivitiesInStorage();
  }
};

const isIntervalOpenInPreviousHour = (Intervals, hCurrent, h) => {
  const openInterval = Intervals.find(({ End }) => !End);
  // Any different hour counts as previous (handles multi-hour gaps and midnight rollover)
  return hCurrent !== h && openInterval;
};

const setActivityScreenTimeEnd = (timestamp = Date.now(), { closing = false } = {}) => {
  const hCurrent = (new Date(timestamp)).getHours();
  Object.keys(activities).forEach((key) => {
    const { Url: url, Intervals } = activities[key];
    const h = parseInt(key.replace(`-${url}`, ''), 10);
    if (isIntervalOpenInPreviousHour(Intervals, hCurrent, h)) {
      // close the interval at the end of its own hour
      const openInterval = Intervals.find(({ End: e }) => !e);
      const startOfIntervalHour = getStartOfTheHour(openInterval.Start);
      const endOfIntervalHour = startOfIntervalHour + 3600000 - 1;
      if (openInterval.Start <= endOfIntervalHour) {
        setIntervalEndInMemory(`${h}-${url}`, endOfIntervalHour);
      } else {
        setIntervalEndInMemory(`${h}-${url}`, timestamp);
      }
      if (!closing) {
        // Only create bridging interval when transitioning to a new tab/URL,
        // not when stopping tracking (idle, sleep, shutdown)
        const startOfCurrentHour = getStartOfTheHour(timestamp);
        setIntervalStartInMemory(`${hCurrent}-${url}`, startOfCurrentHour, url);
        setIntervalEndInMemory(`${hCurrent}-${url}`, timestamp);
      }
      // persist all changes once
      saveActivitiesInStorage();
    } else {
      // close the interval for the current hour
      setIntervalEnd(key, timestamp);
    }
  });
};

const windowFocusListener = async (id) => {
  lastFocusWindowId = id;
  if (id !== chrome.windows.WINDOW_ID_NONE) {
    lastRealFocusWindowId = id;
  }
  const now = Date.now();
  logger.info('onFocusChanged. window active', id);
  setActivityScreenTimeEnd(now);
  if (id === chrome.windows.WINDOW_ID_NONE) {
    return;
  }
  setActivityScreenTimeStart(id, now);
};

const tabActivatedListener = async ({ windowId }) => {
  lastFocusWindowId = windowId;
  if (windowId !== chrome.windows.WINDOW_ID_NONE) {
    lastRealFocusWindowId = windowId;
  }
  const now = Date.now();
  logger.info('onActivated');
  setActivityScreenTimeEnd(now);
  try {
    const win = await chrome.windows.get(windowId);
    if (!win.focused) {
      logger.info('onActivated: window not focused, skipping start');
      return;
    }
  } catch (e) {
    // window may have been closed
    return;
  }
  setActivityScreenTimeStart(windowId, now);
};

const tabUpdatedListener = async (tabId, change, tab) => {
  const { url } = change;
  if (!url) {
    return;
  }
  const { windowId } = tab;
  lastFocusWindowId = windowId;
  if (windowId !== chrome.windows.WINDOW_ID_NONE) {
    lastRealFocusWindowId = windowId;
  }
  const now = Date.now();
  logger.info('onUpdated');
  setActivityScreenTimeEnd(now);
  try {
    const win = await chrome.windows.get(windowId);
    if (!win.focused) {
      logger.info('onUpdated: window not focused, skipping start', url);
      return;
    }
  } catch (e) {
    // window may have been closed
    return;
  }
  setActivityScreenTimeStart(windowId, now);
};

const runtimeConnectListener = (port) => {
  if (port.name !== 'insight') {
    return;
  }
  port.onDisconnect.addListener(() => {
    if (chrome.runtime.lastError) {
      logger.info('[onDisconnect] Port closed:', chrome.runtime.lastError.message);
    }
  });
  port.onMessage.addListener(async (msg) => {
    logger.info(msg);
    // make another attempt to make the user idle
    await setLastSend('lastActivityScreen');
    if (userIdle) {
      logger.info('[onMessage] user active');
      userIdle = false;
      // Use last known real (non-NONE) focused window, but guard against closed windows
      const candidateWindowId = lastRealFocusWindowId;
      if (!candidateWindowId || candidateWindowId === chrome.windows.WINDOW_ID_NONE) {
        setActivityScreenTimeStart(chrome.windows.WINDOW_ID_NONE);
      } else {
        try {
          await chrome.windows.get(candidateWindowId);
          setActivityScreenTimeStart(candidateWindowId);
        } catch (e) {
          // Window no longer exists; fall back to a safe value
          setActivityScreenTimeStart(chrome.windows.WINDOW_ID_NONE);
        }
      }
    } else {
      userIdle = false;
    }
  });
};

const extensionUpdateAvailableListener = async () => {
  // send whatever data it has
  await trySendActivity();
  // reload
  chrome.runtime.reload();
};

async function getDEDeviceInfo() {
  // get more details. resolveDeviceId / resolveUserId prefer the
  // native CatchOn agent's values when it's connected on localhost;
  // fall back to the extension's own derivation otherwise.
  // (Note: getDEDeviceInfo doesn't include PII, so we don't need
  // getProfileData() here — only the hashed UserHash.)
  const machineId = await resolveDeviceId();
  const userId = await resolveUserId();
  const deviceType = await getDeviceType();
  const key = await getManagedValue('EntitlementKey');
  const manifest = getManifest();
  const processor = await getCPU();
  const storage = await getStorage();
  const memory = await getMemory();
  const deviceOS = await getOS();
  const deviceOSVersion = await getOSVersion();

  // build storage info from partitions array
  let storageInfo;
  if (!storage?.length) {
    storageInfo = { Error: 'No storage info available' };
  } else if (deviceOS !== 'mac') {
    storageInfo = storage
      .filter((d) => d.type === 'fixed')
      .reduce((acc, d) => {
        acc.Total += d.capacity;
        return acc;
      }, {
        Total: 0,
      });
  } else {
    const capacities = storage
      .filter((d) => d.type === 'fixed')
      .reduce((acc, d) => {
        // pick only unique capacities
        if (acc.indexOf(d.capacity) === -1) {
          acc.push(d.capacity);
        }
        return acc;
      }, []);
    storageInfo = capacities.reduce((acc, c) => {
      acc.Total += c;
      return acc;
    }, {
      Total: 0,
    });
  }

  return {
    Version: manifest.version,
    DeviceId: machineId,
    DeviceType: deviceType,
    DeviceOSVersion: deviceOSVersion,
    UserHash: userId,
    EntitlementKey: key,
    Platform: platform === 'chrome' ? 'catchon-extension' : platform,
    SentAt: Date.now(),
    Processor: processor ? {
      ModelName: processor.modelName,
      CoreCount: processor.numOfProcessors,
      Family: processor.archName,
    } : { Error: 'No processor info available' },
    Disk: storageInfo,
    Memory: memory?.capacity ? {
      Total: memory.capacity,
      Free: memory.availableCapacity,
      UsedPercent: Math.floor(((memory.capacity - memory.availableCapacity) / memory.capacity) * 100),
    } : { Error: 'No memory info available' },
  };
}

const checkForSpeedAndLocation = async () => {
  if (speedTestInProgress) {
    logger.info('[checkForSpeedAndLocation] Speed test is still in progress');
    return;
  }
  if (config?.speedTestURL && config?.chunkSize && config?.chunkCount) {
    const randomTime = getRandomInt(1, 55);
    logger.info(`[checkForSpeedAndLocation] Waiting ${randomTime} seconds`);
    await wait(randomTime * 1000);
    // CAT-18113: when the native CatchOn agent is connected on localhost,
    // it is the source of truth for digital-equity signals on this device.
    // Skip the scheduled speed-test run (no WASM, no upload). Checked
    // AFTER the random wait so an agent that connects mid-window still
    // gates this run (AC-4).
    if (agentLink.isAgentConnected()) {
      logger.info('[checkForSpeedAndLocation] agent connected, skipping DE speed test run');
      return;
    }
    // get last time the check was done
    const localStorage = await chrome.storage.local.get(['lastCheckTime', 'lastCheckIP']);
    const now = new Date();
    if (
      // no check was done
      !localStorage.lastCheckTime
      // too much time has passed since last check
      || (localStorage.lastCheckTime && now.getTime() >= localStorage.lastCheckTime + (config.maxCheck * 60 * 1000))
      // min time has passed and IPs have changed
      || (localStorage.lastCheckTime && now.getTime() >= localStorage.lastCheckTime + (config.minCheck * 60 * 1000)
        && currentIP !== localStorage.lastCheckIP)
    ) {
      speedTestInProgress = true;
      await setLastSend('lastSpeedLocation');
      await chrome.storage.local.set({
        lastCheckTime: new Date().getTime(),
      });

      if (config.locationDataActive) {
        logger.info('[checkForSpeedAndLocation] get location');
        try {
          locating = await getGeolocation();

          logger.info('locating', locating);

          if (locating.error) {
            logger.info('[checkForSpeedAndLocation] Could not get location', locating.message);
            currentLatitude = null;
            currentLongitude = null;
          } else {
            const { coords } = locating;
            const { latitude, longitude } = coords;
            currentLatitude = latitude;
            currentLongitude = longitude;
          }
        } catch (e) {
          logger.info('[checkForSpeedAndLocation] Could not get location', e);
        } finally {
          locating = null;
        }
      }

      let speedTestData = {};
      // speed test
      logger.info('[checkForSpeedAndLocation] firing up the speed test');
      try {
        const speedConfig = {
          server: config.speedTestURL,
          chunkSize: config.chunkSize,
          chunkCount: config.chunkCount,
          maxPayloadSize: config.maxPayload,
          adaptiveThreshold: config.adaptiveLimit,
        };
        speedTestData = await speedTest(speedConfig);
        logger.info(speedTestData);
      } catch (e) {
        logger.info('[checkForSpeedAndLocation] Could not start speed test', e);
      }

      if (speedTestData?.Results?.TransactionId) {
        // Send equity data only if speed test was successful
        currentIP = speedTestData?.IP;
        await chrome.storage.local.set({
          lastCheckIP: currentIP,
        });

        const moreDeviceDetails = await getDEDeviceInfo();
        const body = {
          ...moreDeviceDetails,
          Connected: true,
          IP: currentIP,
          SpeedTest: speedTestData.Results,
          Location: config.locationDataActive && currentLatitude && currentLongitude ? {
            Lat: currentLatitude,
            Lon: currentLongitude,
          } : undefined,
        };

        try {
          // sent digital equity data
          const res = await sendData({
            url: config.digitalEquityURL,
            body,
          });
          logger.info(res);
        } catch (e) {
          logger.info(`Error sending digital equity data: ${e.message}`);
          if (e instanceof CriticalError) {
            throw e;
          }
        } finally {
          speedTestInProgress = false;
        }
      }
    }
  } else {
    logger.info('Cannot run speed test without all the configs.');
  }
};

const trySendDisconnectedData = async () => {
  if (config.speedTestActive) {
    // CAT-18113: the native agent owns digital-equity reporting when
    // connected. Skip uploading any buffered offline interval AND
    // discard the buffered record so a later agent disconnect cannot
    // flush stale pre-change data (AC-5).
    if (agentLink.isAgentConnected()) {
      logger.info('[trySendDisconnectedData] agent connected, skipping DE disconnect send');
      await chrome.storage.local.remove('offlineInfo');
      return;
    }
    logger.info('Send offline data if online and available');
    if (navigator.onLine) {
      // get offline info if available
      const localStorage = await chrome.storage.local.get(['offlineInfo']);

      if (localStorage.offlineInfo) {
        logger.info('Sending offline data');
        lastOfflineDetails = JSON.parse(localStorage.offlineInfo);
        logger.info(lastOfflineDetails);
        if (!lastOfflineDetails.DisconnectEnd) {
          lastOfflineDetails.DisconnectEnd = new Date().getTime();
        }

        const moreDeviceDetails = await getDEDeviceInfo();
        const body = {
          ...moreDeviceDetails,
          Connected: false,
          IP: lastOfflineDetails.LastIP,
          DisconnectedInterval: {
            Start: lastOfflineDetails.DisconnectStart,
            End: lastOfflineDetails.DisconnectEnd,
          },
        };

        try {
          // sent digital equity disconnected ata
          const res = await sendData({
            url: config.digitalEquityURL,
            body,
          });
          logger.info(res);
          // Reset disconnected data
          await chrome.storage.local.remove('offlineInfo');
        } catch (e) {
          logger.info(`Error sending digital equity disconnected data: ${e.message}`);
          if (e instanceof CriticalError) {
            throw e;
          }
        }
      } else {
        logger.info('No offline data to send');
      }
    }
  }
};

async function loadLastSend() {
  lastSend = await getLocalStorage('lastSend') || {};
}

async function loadConfig() {
  const lc = await getLocalStorage('config');
  if (lc) {
    config = lc;
  } else {
    config = await getDefaultConfig();
    await checkKey(config);
  }
  logger.init(config.log);
}

const cleanupStaleIntervals = async () => {
  const { lastActiveTime } = await chrome.storage.local.get(['lastActiveTime']);
  const closeTime = lastActiveTime || Date.now();
  const maxIntervalMs = sendActivityInt;
  let cleanedUp = false;

  Object.keys(activities).forEach((key) => {
    const activity = activities[key];
    activity.Intervals?.forEach((interval) => {
      if (!interval.End) {
        const calculatedEnd = Math.min(closeTime, interval.Start + maxIntervalMs);
        const validEnd = Math.max(calculatedEnd, interval.Start);
        logger.info(`Cleaning up stale interval for ${key} and setting end time to ${new Date(validEnd).toISOString()}`);

        interval.End = validEnd;
        cleanedUp = true;
      }
    });
  });

  // Save the cleaned up activities to storage
  if (cleanedUp) {
    await saveActivitiesInStorage();
  }
};

const start = () => {
  // setup worker alarm
  logger.info('[main] creating worker alarm');
  chrome.alarms.create('worker', { periodInMinutes: 1 });

  // logic to keep alive
  if (keepAliveInterval) {
    clearInterval(keepAliveInterval);
  }
  keepAliveInterval = setInterval(() => {
    chrome.runtime.getPlatformInfo(() => {
      if (chrome.runtime.lastError) {
        logger.info('[keepAlive] error:', chrome.runtime.lastError.message);
        return;
      }
      logger.info('[keepAlive]');
    });

    const now = Date.now();
    const diff = now - lastTick;

    // Detect too-large gap = system was asleep
    if (diff > HEARTBEAT * HEARTBEAT_THRESHOLD_MULTIPLIER) {
      const sleepStart = lastTick + HEARTBEAT;
      logger.info('System slept. Estimated sleep start:', new Date(sleepStart));

      // End activity at the moment sleep began, not now
      // Use closing=true to prevent phantom bridging intervals across hours
      setActivityScreenTimeEnd(sleepStart, { closing: true });
      userIdle = true;
    }

    lastTick = now;
  }, HEARTBEAT);
};

const main = async () => {
  // grab last send times
  await loadLastSend();
  // grab config
  await loadConfig();
  // load activities from storage
  activities = await readActivitiesFromStorage();

  // update send interval before cleanup so it uses the correct cap
  updateSendInterval();

  // Clean up any stale intervals from browser shutdown
  await cleanupStaleIntervals();
  // do an initial check on init
  await checkAgentStatus();
  // Send disconnected data if available
  await trySendDisconnectedData();
};

let mainInt;
const runMainUntilSuccess = async () => {
  try {
    await main();
  } catch (e) {
    logger.info('Running main program failed with error: ', e);
    // try again after 1 minute
    clearTimeout(mainInt);
    mainInt = setTimeout(runMainUntilSuccess, min1);
    throw e;
  }
};

if (typeof process === 'undefined' || typeof process.env === 'undefined' || process.env.NODE_ENV !== 'test') {
  // run when loaded (eg: after restart)
  runMainUntilSuccess();
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'worker') {
    logger.info('[onAlarm] worker');
    await loadLastSend();

    // attempt agent check, but do not block activity send if it fails
    try {
      await checkAgentStatus();
    } catch (error) {
      logger.info('Agent status check failed:', error?.message || error);
    }

    // attempt send
    await trySendActivity();

    if (lastSend.lastActivityScreen && timeToRun(lastSend.lastActivityScreen, lastActivityInt)) {
      logger.info('[onAlarm] user idle');
      setActivityScreenTimeEnd(undefined, { closing: true });
      userIdle = true;
    }

    // check speedtest if enabled
    if (config.speedTestActive) {
      if (!lastSend.lastSpeedLocation || timeToRun(lastSend.lastSpeedLocation, speedLocationInt)) {
        if (navigator.onLine) {
          logger.info('[onAlarm] start speed test process');
          checkForSpeedAndLocation();
          trySendDisconnectedData();
        }
      }
    }
  }
});

navigator.connection.onchange = async () => {
  // Status changed
  if (config.speedTestActive) {
    // CAT-18113: do not record disconnect-interval boundaries when the
    // native agent is connected. Keep currentConnectionStatus in sync
    // so a later agent disconnect doesn't cause a stale-state mis-fire
    // on the next transition (AC-3 / AC-7).
    if (agentLink.isAgentConnected()) {
      logger.info('[connection.onchange] agent connected, skipping DE disconnect recording');
      currentConnectionStatus = navigator.onLine;
      return;
    }
    if (navigator.onLine !== currentConnectionStatus) {
      if (navigator.onLine) {
        logger.info('Changed from offline to online');
        currentConnectionStatus = true;
        const localStorage = await chrome.storage.local.get(['offlineInfo']);

        if (localStorage.offlineInfo) {
          lastOfflineDetails = JSON.parse(localStorage.offlineInfo);

          // Mark end date of disconnection
          lastOfflineDetails.DisconnectEnd = new Date().getTime();
          await chrome.storage.local.set({ offlineInfo: JSON.stringify(lastOfflineDetails) });

          await trySendDisconnectedData();
        }
      } else if (!navigator.onLine) {
        logger.info('Changed from online to offline');
        currentConnectionStatus = false;
        const localStorage = await chrome.storage.local.get(['lastCheckIP']);
        const offlineDetails = {
          LastIP: localStorage.lastCheckIP,
          DisconnectStart: new Date().getTime(),
        };
        await chrome.storage.local.set({ offlineInfo: JSON.stringify(offlineDetails) });
      }
    }
  }
};

const onSuspendListener = async () => {
  logger.info('[onSuspend] Browser closing or extension being suspended');
  // End all active activities — use closing=true to prevent phantom bridging intervals
  setActivityScreenTimeEnd(undefined, { closing: true });
  await saveActivitiesInStorage();
};

const windowRemovedListener = async (windowId) => {
  logger.info('[onRemoved] Window closed', windowId);
  // Check if there are any remaining windows
  try {
    const windows = await chrome.windows.getAll();
    if (windows.length === 0) {
      logger.info('[onRemoved] Last window closed, ending active activities if any');
      setActivityScreenTimeEnd(undefined, { closing: true });
      await saveActivitiesInStorage();
    }
  } catch (error) {
    logger.info('Error getting windows:', error.message);
  }
};

chrome.windows.onFocusChanged.addListener(windowFocusListener);
chrome.windows.onRemoved.addListener(windowRemovedListener);
chrome.tabs.onActivated.addListener(tabActivatedListener);
chrome.tabs.onUpdated.addListener(tabUpdatedListener);
chrome.runtime.onConnect.addListener(runtimeConnectListener);
chrome.runtime.onUpdateAvailable.addListener(extensionUpdateAvailableListener);
chrome.runtime.onStartup.addListener(start);
// Handle browser shutdown / extension unload
chrome.runtime.onSuspend.addListener(onSuspendListener);

// workaround for issue where onFocusChanged is not always fired
setInterval(() => {
  chrome.windows.getLastFocused((focusedWindow) => {
    if (chrome.runtime.lastError) {
      // Handle error when no windows are available (e.g., browser closing)
      logger.info('No last-focused window available:', chrome.runtime.lastError.message);
      return;
    }
    if (!focusedWindow) {
      return;
    }
    if (focusedWindow.focused && focusedWindow.id !== lastFocusWindowId) {
      logger.info('onFocusChanged workaround. window active', focusedWindow.id);
      windowFocusListener(focusedWindow.id);
    } else if (!focusedWindow.focused && lastFocusWindowId !== chrome.windows.WINDOW_ID_NONE) {
      logger.info('onFocusChanged workaround. window none');
      windowFocusListener(chrome.windows.WINDOW_ID_NONE);
    }
  });

  chrome.storage.local.set({ lastActiveTime: Date.now() });
}, 1000);

start();

export {
  main,
  getActivities,
  setActivityScreenTimeStart,
  setActivityScreenTimeEnd,
  clearActivities,
  // Exposed for CAT-18113 unit tests so the agent-connection gates can be
  // exercised directly without dispatching the worker alarm.
  checkForSpeedAndLocation,
  trySendDisconnectedData,
  // Exposed for unit tests so the agent-connection gates and report
  // routing can be exercised directly without dispatching the worker alarm.
  sendActivity,
};
